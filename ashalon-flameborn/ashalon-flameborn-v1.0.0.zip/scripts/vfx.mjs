import { MODULE_ID as ID, currentForm, moduleFlags as flags } from "./core.mjs";

// Media is resolved from the user's installed JB2A database; no JB2A files are distributed.
const candidates = {
  body: ["jb2a.flames.01.orange", "jb2a.token_border.circle.spinning.orange.001", "jb2a.token_border.circle.static.orange.001"],
  soul: ["jb2a.token_border.circle.spinning.orange.001", "jb2a.token_border.circle.static.orange.001", "jb2a.flames.01.orange"],
  burst: ["jb2a.fireball.explosion.orange", "jb2a.explosion.01.orange", "jb2a.impact.004.orange"],
};
const active = new Map();
let warned = false;
const available = () => game.modules.get("sequencer")?.active && globalThis.Sequence && globalThis.Sequencer?.EffectManager;
const setting = key => game.settings.get(ID, key);
export function asset(kind) {
  if (!available()) return null;
  const custom = String(setting(`${kind}Animation`) ?? "").trim();
  if (custom && /\.(webm|mp4|gif|png|webp|svg)(\?.*)?$/i.test(custom)) return custom;
  for (const key of [custom, ...candidates[kind]].filter(Boolean)) {
    try { if (Sequencer.Database.entryExists(key)) return key; } catch { /* optional database */ }
  }
  return null;
}
export function registerVFXSettings() {
  game.settings.register(ID, "animations", { name: "Flameborn animations", hint: "Play optional JB2A effects using Sequencer. Native token light and all game rules work without animations.", scope: "client", config: true, type: Boolean, default: true,
    onChange: () => { void reconcileVFX(); } });
  for (const [kind, name] of [["body", "Blazing Body"], ["soul", "Blazing Soul"], ["burst", "Explosive Bound"]]) {
    game.settings.register(ID, `${kind}Animation`, { name: `${name} animation`, hint: "Optional Sequencer database key or installed media path. Blank selects an available JB2A animation automatically.", scope: "world", config: true, type: String, default: "" });
  }
}
async function end(name) {
  if (available()) await Sequencer.EffectManager.endEffects({ name });
  active.delete(name);
}
export async function reconcileVFX() {
  if (!canvas?.ready || !available()) return;
  const desired = new Map();
  if (setting("animations")) for (const token of canvas.tokens.placeables) {
    const form = token.actor && currentForm(token.actor);
    if (!form) continue;
    const name = `${ID}.${token.document.uuid}.${form.id}`;
    desired.set(name, { token, form });
  }
  for (const name of [...active.keys()]) if (!desired.has(name)) await end(name);
  for (const [name, { token, form }] of desired) {
    if (active.has(name)) continue;
    const file = asset(flags(form).manifestation === "soul" ? "soul" : "body");
    if (!file) {
      if (!warned && game.user.isGM) {
        ui.notifications.info("Flameborn: no matching JB2A aura was found. Select an installed animation in Module Settings; the transformation’s rules and light are active.");
        warned = true;
      }
      continue;
    }
    active.set(name, true);
    try {
      // A local long-running loop avoids persistent token flags and duplicated broadcasts.
      // Every client recreates its own visuals on canvasReady and removes them on item expiry.
      const sequence = new Sequence();
      sequence.effect().file(file).attachTo(token).scaleToObject(1.55).opacity(0.5)
        .duration(86_400_000).fadeIn(350).fadeOut(250).name(name).locally();
      void sequence.play().catch(error => { active.delete(name); console.warn(`${ID} | Animation unavailable`, error); });
    } catch (error) { active.delete(name); console.warn(`${ID} | Animation unavailable`, error); }
  }
}
export async function clearVFX() {
  for (const name of [...active.keys()]) await end(name);
}
export async function boundVFX(actor) {
  if (!available() || !setting("animations")) return;
  const file = asset("burst");
  if (!file) return;
  const token = actor.getActiveTokens()?.[0];
  if (!token) return;
  try {
    const sequence = new Sequence();
    sequence.effect().file(file).atLocation(token).scaleToObject(1.8).opacity(0.7);
    void sequence.play().catch(error => console.warn(`${ID} | Bound animation`, error));
  } catch (error) { console.warn(`${ID} | Bound animation`, error); }
}
