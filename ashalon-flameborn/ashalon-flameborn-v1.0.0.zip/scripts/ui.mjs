import { MODULE_ID as ID, VERSION, escapeHTML as esc, levelOf, findFeat, hasFeat, isFlameborn,
  moduleFlags as flags, stateOf, currentForm, remainingUses, canRerollAthletics, itemsOf } from "./core.mjs";
import { activate, dismiss, bound, reroll, synchronizeSpells, chooseAlternateAthletics, requireOwner,
  now, state, safe, getCatalog, cleanupActor } from "./features.mjs";
import { armSpell, applySpellShield } from "./spells.mjs";
import { reconcileVFX, asset } from "./vfx.mjs";

export const interactive = new Set(["primordial-flame", "surpass-your-limits", "flame-fed-by-trial", "explosive-bound", "emberward-spell", "piercing-embers", "living-conduit"]);
export async function selectedActor() {
  const selected = canvas?.tokens?.controlled?.filter(t => t.actor?.isOwner).map(t => t.actor) ?? [];
  if (selected.length === 1) return selected[0];
  if (selected.length > 1) throw new Error("Select one character token.");
  if (game.user.character?.isOwner) return game.user.character;
  const choices = game.actors.filter(a => a.type === "character" && a.isOwner && isFlameborn(a));
  if (choices.length === 1) return choices[0];
  if (!choices.length) throw new Error("Select a character token and add the Flameborn heritage from its compendium.");
  const result = await foundry.applications.api.DialogV2.input({ window: { title: "Choose a Flameborn" },
    content: `<select name="actor">${choices.map(a => `<option value="${esc(a.uuid)}">${esc(a.name)}</option>`).join("")}</select>`, ok: { label: "Open" } });
  return result ? fromUuid(result.actor) : null;
}
function status(actor, slug) {
  const item = findFeat(actor, slug);
  if (!item?.system.frequency) return "";
  const uses = remainingUses(item, now());
  const readyAt = flags(item).readyAt;
  return `${uses}/${item.system.frequency.max} uses${uses === 0 && readyAt ? ` · ${Math.ceil(Math.max(0, readyAt - now()) / 60)} game minutes until ready` : ""}`;
}
export async function feature(actor, slug) {
  if (slug === "primordial-flame") return activate(actor);
  if (slug === "flame-fed-by-trial") return activate(actor, { trial: true });
  if (slug === "explosive-bound") return bound(actor);
  if (["soul", "emberward-spell", "piercing-embers", "living-conduit"].includes(slug)) return armSpell(actor, slug);
  if (slug === "surpass-your-limits") {
    const messages = game.messages.contents.filter(m => m.actor?.uuid === actor.uuid && canRerollAthletics(m) && (m.isAuthor || game.user.isGM)).slice(-12).reverse();
    if (!messages.length) throw new Error("There is no eligible failed Athletics check in chat. Roll the check first.");
    const choice = await foundry.applications.api.DialogV2.input({ window: { title: "Surpass Your Limits" },
      content: `<p>Choose the check that just triggered this free action.</p><select name="message">${messages.map(m => `<option value="${m.id}">${esc(m.flags.pf2e.context.title ?? "Athletics")} — ${m.rolls[0].total}</option>`).join("")}</select>`, ok: { label: "Reroll — Keep Best" } });
    if (choice && messages.some(m => m.id === choice.message)) return reroll(game.messages.get(choice.message));
  }
}
export async function openControls(actor = null) {
  actor ??= await selectedActor(); if (!actor) return;
  requireOwner(actor);
  await cleanupActor(actor);
  const form = currentForm(actor);
  const pending = stateOf(actor).pendingSpell;
  const choices = [];
  if (hasFeat(actor, "primordial-flame")) choices.push({ id: form ? "dismiss" : "primordial-flame", name: form ? "Dismiss Primordial Flame · 1 action" : "Awaken Primordial Flame · 1 action", detail: status(actor, "primordial-flame") });
  if (flags(form).manifestation === "soul") choices.push({ id: "soul", name: "Choose Blazing Soul benefit for your next spell", detail: "Once on each of your own turns" });
  for (const [id, title] of [["flame-fed-by-trial", "Flame Fed by Trial · reaction"], ["surpass-your-limits", "Surpass Your Limits · free action"], ["explosive-bound", "Explosive Bound · 1 action"], ["emberward-spell", "Emberward Spell · 1 action"], ["piercing-embers", "Piercing Embers · 1 action"], ["living-conduit", "Living Conduit · free action"]]) {
    if (hasFeat(actor, id)) choices.push({ id, name: title, detail: status(actor, id) });
  }
  if (pending) choices.push({ id: "clear", name: "Clear pending spell benefits", detail: "A spent spellshape use is not refunded" });
  if (hasFeat(actor, "kindled-soul")) choices.push({ id: "spells", name: "Set up / repair Flameborn innate spells", detail: "Keeps existing spells and their remaining daily uses" });
  if (flags(findFeat(actor, "peak-physiology")).needsAthleticsFeat) choices.push({ id: "athletics", name: "Choose Peak Physiology’s alternate Athletics feat", detail: "Titan Wrestler was already known" });
  choices.push({ id: "rules", name: "Open Flameborn heritage and feats", detail: "Compendium" });
  const header = `<div class="flameborn-banner"><img src="modules/${ID}/icons/flame.svg" alt=""><div><strong>${esc(actor.name)}</strong><p>${form ? esc(form.name) : "The ember sleeps."}</p></div></div>`;
  const info = `<p>Level ${levelOf(actor)} · Fire resistance ${Math.max(1, Math.floor(levelOf(actor) / 2))}${hasFeat(actor, "worthy-of-inari") ? ` · Worthy of Inari: ${status(actor, "worthy-of-inari")}` : ""}</p>`;
  const queued = pending ? `<p class="flameborn-notice">Next spell: ${esc([pending.soul?.mode, pending.shape?.kind, pending.conduit ? "Living Conduit" : null].filter(Boolean).join(", "))}. Cast normally from your sheet.</p>` : "";
  const result = await foundry.applications.api.DialogV2.input({ window: { title: "Flameborn" }, position: { width: 490 },
    content: `<div class="flameborn-form">${header}${info}${queued}<div class="flameborn-options">${choices.map((c, n) => `<label><input type="radio" name="action" value="${c.id}" ${n === 0 ? "checked" : ""}><span><b>${esc(c.name)}</b><small>${esc(c.detail)}</small></span></label>`).join("")}</div></div>`, ok: { label: "Use Selected" } });
  if (!result) return;
  if (result.action === "dismiss") return dismiss(actor);
  if (result.action === "clear") return state(actor, { pendingSpell: null });
  if (result.action === "spells") { await synchronizeSpells(actor); ui.notifications.info("Flameborn innate spells synchronized."); return; }
  if (result.action === "athletics") return chooseAlternateAthletics(actor);
  if (result.action === "rules") return game.packs.get(`${ID}.heritage-feats`)?.render(true);
  return feature(actor, result.action);
}

export function renderSheet(app, html) {
  const actor = app.actor ?? app.document;
  const root = html instanceof HTMLElement ? html : html?.[0];
  if (!root || !actor?.isOwner || !isFlameborn(actor)) return;
  if (!root.dataset.flamebornBound) {
    root.dataset.flamebornBound = "true";
    root.addEventListener("click", event => {
      const action = event.target.closest('[data-action="use-action"]');
      const id = action?.closest("[data-item-id]")?.dataset.itemId;
      const item = actor.items.get(id);
      const slug = flags(item).feature;
      if (action && interactive.has(slug)) {
        event.preventDefault(); event.stopImmediatePropagation();
        void safe(() => feature(actor, slug));
      }
    }, true);
  }
  if (!root.querySelector(".flameborn-open")) {
    const button = document.createElement("button"); button.type = "button"; button.className = "flameborn-open";
    button.innerHTML = '<i class="fa-solid fa-fire" inert></i> Flameborn';
    button.addEventListener("click", event => { event.preventDefault(); event.stopPropagation(); void safe(() => openControls(actor)); });
    const host = root.querySelector(".sheet-header") ?? root.querySelector(".window-content") ?? root;
    host.prepend(button);
  }
}

export function renderChat(message, html) {
  const root = html instanceof HTMLElement ? html : html?.[0];
  if (!root || root.querySelector(".flameborn-chat-controls")) return;
  const div = document.createElement("div"); div.className = "flameborn-chat-controls";
  function button(label, callback) { const b = document.createElement("button"); b.type = "button"; b.textContent = label;
    b.addEventListener("click", () => { b.disabled = true; void safe(callback).finally(() => { b.disabled = false; }); }); div.append(b); }
  const actor = message.actor;
  if (actor?.isOwner && hasFeat(actor, "surpass-your-limits") && canRerollAthletics(message) && (message.isAuthor || game.user.isGM)) button("Surpass Your Limits — reroll, keep best", () => reroll(message));
  const f = flags(message);
  if (f.trial && actor?.isOwner) button("Flame Fed by Trial — use reaction", () => activate(actor, { trial: true }));
  const cast = f.cast;
  if (cast) {
    const p = document.createElement("p");
    p.textContent = [cast.soul?.mode === "searing" ? `Blazing Soul: +${cast.rank} fire to ${cast.soul.target.name} on this spell’s first damage roll.` : null,
      cast.soul?.mode === "sheltering" ? `Sheltering magic: ${cast.rank} temporary HP after resolution.` : null,
      cast.shape?.kind === "piercing" ? `Piercing Embers: ignore ${Math.floor(cast.level / 2)} fire resistance on initial damage.` : null,
      cast.conduit ? "Living Conduit: spell slot preserved." : null].filter(Boolean).join(" ");
    if (p.textContent) div.append(p);
    if (cast.soul?.mode === "sheltering") button(`After resolution: shelter ${cast.soul.target.name}`, () => applySpellShield(message, "sheltering"));
    if (cast.shape?.kind === "emberward") button(`After resolution: Emberward ${cast.shape.target.name}`, () => applySpellShield(message, "emberward"));
  }
  if (f.damage) { const p = document.createElement("p");
    p.textContent = f.damage.searing ? `Flameborn: the displayed total is the base spell damage. Applying this roll to ${f.damage.soul.target.name} adds ${f.damage.rank} fire before save/critical adjustments and resistance.` : "Piercing Embers applies when using this roll’s normal damage buttons.";
    div.append(p);
  }
  if (div.childNodes.length) (root.querySelector(".message-content") ?? root).append(div);
}

export async function diagnostics() {
  const actor = await selectedActor();
  const details = {
    module: VERSION, foundry: game.version, pf2e: game.system.version,
    libWrapper: !!game.modules.get("lib-wrapper")?.active,
    sequencer: game.modules.get("sequencer")?.version ?? "not installed",
    bodyAnimation: asset("body"), soulAnimation: asset("soul"), burstAnimation: asset("burst"),
    catalog: { feats: getCatalog()?.feats.length, effects: getCatalog()?.effects.length },
    actor: actor ? { name: actor.name, level: levelOf(actor), heritage: isFlameborn(actor), form: currentForm(actor)?.name ?? null,
      fireResistance: actor.system.attributes.resistances?.find(r => r.type === "fire")?.value,
      pendingSpell: stateOf(actor).pendingSpell ?? null,
      innateSpells: itemsOf(actor).filter(i => flags(i).managedSpell).map(i => i.name) } : null,
  };
  console.info(`${ID} | Diagnostics`, details);
  await foundry.applications.api.DialogV2.wait({ window: { title: "Flameborn diagnostics" }, position: { width: 600 },
    content: `<pre class="flameborn-diagnostics">${esc(JSON.stringify(details, null, 2))}</pre>`, buttons: [{ action: "close", label: "Close", default: true }], rejectClose: false });
  await reconcileVFX();
  return details;
}
