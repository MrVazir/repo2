/** Pure rules and serialization helpers. No Foundry globals. */
export const MODULE_ID = "ashalon-flameborn";
export const VERSION = "1.0.0";
export const FORM_SLUG = "effect-flameborn-primordial-flame";
export const clone = value => structuredClone(value);
export const slugify = value => String(value).toLowerCase().replace(/[’']/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
export const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]);
export const levelOf = actor => Number(actor?.level ?? actor?.system?.details?.level?.value ?? 1);
export const itemsOf = actor => Array.from(actor?.items?.contents ?? actor?.items ?? []);
export const itemSlug = item => item?.slug ?? item?.system?.slug ?? slugify(item?.name ?? "");
export const findFeat = (actor, slug) => itemsOf(actor).find(i => i.type === "feat" && itemSlug(i) === slug);
export const hasFeat = (actor, slug) => !!findFeat(actor, slug);
export const isFlameborn = actor => itemsOf(actor).some(i => i.type === "heritage" && itemSlug(i) === "flameborn");
export const moduleFlags = document => document?.flags?.[MODULE_ID] ?? {};
export const stateOf = actor => moduleFlags(actor).state ?? {};
export const currentForm = actor => itemsOf(actor).find(i => i.type === "effect" && itemSlug(i) === FORM_SLUG && !i.isExpired && !i.system?.expired);
export const conscious = actor => Number(actor?.system?.attributes?.hp?.value ?? 0) > 0 && !actor?.hasCondition?.("unconscious") && !actor?.isDead;
export const crossedHalf = (before, after, maximum) => maximum > 0 && before > maximum / 2 && after > 0 && after <= maximum / 2;

export function remainingUses(item, now = 0) {
  if (!item) return 0;
  const frequency = item.system?.frequency;
  if (!frequency) return Infinity;
  const flags = moduleFlags(item);
  if (Number.isFinite(flags.readyAt) && now >= flags.readyAt) return frequency.max ?? 1;
  return Math.max(0, Number(frequency.value ?? frequency.max ?? 1));
}

export function turnStamp(combat, nowMs = Date.now()) {
  return combat?.started ? `${combat.id}:${combat.round}:${combat.turn}` : `exploration:${Math.floor(nowMs / 6000)}`;
}

export function ownTurn(actor, combat) {
  return !combat?.started || combat.combatant?.actor?.uuid === actor.uuid;
}

export function highestSlotRank(actor) {
  return itemsOf(actor).filter(i => i.type === "spellcastingEntry" && ["prepared", "spontaneous"].includes(i.system?.prepared?.value))
    .reduce((highest, entry) => Object.entries(entry.system.slots ?? {}).reduce((n, [key, slot]) => Math.max(n, Number(slot.max) > 0 ? Number(key.replace("slot", "")) || 0 : 0), highest), 0);
}

export function slotAvailable(entry, spell, rank, slotId) {
  const category = entry.system?.prepared?.value;
  if (!["prepared", "spontaneous"].includes(category) || spell.isCantrip || spell.isFocusSpell) return false;
  const slot = entry.system?.slots?.[`slot${rank}`];
  if (!slot) return false;
  if (category === "prepared" && !entry.system.prepared.flexible) {
    const prepared = Object.values(slot.prepared ?? {});
    const id = spell.original?.id ?? spell.id;
    return Number.isInteger(slotId) ? !!prepared[slotId] && prepared[slotId].id === id && !prepared[slotId].expended : prepared.some(s => s.id === id && !s.expended);
  }
  return Number(slot.value) > 0;
}

export function castActions(spell) {
  const value = String(spell.system?.time?.value ?? "");
  return /^[123]$/.test(value.trim()) ? Number(value) : null;
}

export function eligibleConduit(actor, entry, spell, rank, slotId, chosenActions = null) {
  if (!currentForm(actor) || !hasFeat(actor, "living-conduit")) return false;
  if (rank < 1 || rank > highestSlotRank(actor) - 2) return false;
  const actions = chosenActions ?? castActions(spell);
  if (![1, 2, 3].includes(actions)) return false;
  if (String(spell.system?.cost?.value ?? spell.system?.cost ?? "").trim()) return false;
  return slotAvailable(entry, spell, rank, slotId);
}

export function canRerollAthletics(message) {
  const c = message?.flags?.pf2e?.context;
  if (!c || c.isReroll || c.type !== "skill-check" || !["failure", "criticalFailure"].includes(c.outcome)) return false;
  if (c.identifier !== "athletics" && c.statistic !== "athletics" && !(c.domains ?? []).includes("athletics")) return false;
  const options = new Set(c.options ?? []);
  const roll = message.rolls?.[0];
  return !c.rollTwice && !options.has("fortune") && !options.has("misfortune") && !options.has("check:reroll") && roll?.options?.rerollable !== false;
}

/** Serialize modifications exactly as PF2e DamageRoll.alter does, without flattening rolled dice. */
function canonicalTerm(term) {
  if (!term) return null;
  const data = typeof term.toJSON === "function" ? term.toJSON() : term;
  const result = {};
  for (const key of ["class", "number", "faces", "operator", "results", "modifiers", "expression", "fn", "terms"]) if (data[key] !== undefined) result[key] = data[key];
  if (data.term) result.term = canonicalTerm(data.term);
  if (data.operands) result.operands = data.operands.map(canonicalTerm);
  return result;
}

const sameTerm = (a, b) => JSON.stringify(canonicalTerm(a)) === JSON.stringify(canonicalTerm(b));
const termData = t => typeof t?.toJSON === "function" ? t.toJSON() : t;
const numberTerm = t => termData(t)?.class === "NumericTerm" ? Number(termData(t).number) : null;

/** Recover ONLY the public PF2e alter wrapper; reject unknown rewrites instead of guessing. */
export function inferTermAdjustment(original, adjusted) {
  original = termData(original); adjusted = termData(adjusted);
  if (sameTerm(original, adjusted)) return { multiplier: 1, addend: 0 };
  if (adjusted?.class === "Grouping") return inferTermAdjustment(original, adjusted.term);
  if (original?.class === "Grouping" && sameTerm(original.term, adjusted)) return { multiplier: 1, addend: 0 };
  if (adjusted?.class !== "ArithmeticExpression") return null;
  const [left, right] = adjusted.operands ?? [];
  const lnum = numberTerm(left), rnum = numberTerm(right);
  if (adjusted.operator === "*" && lnum !== null) {
    const inner = inferTermAdjustment(original, right);
    return inner ? { multiplier: inner.multiplier * lnum, addend: inner.addend * lnum } : null;
  }
  if (["+", "-"].includes(adjusted.operator) && rnum !== null) {
    const inner = inferTermAdjustment(original, left);
    return inner ? { ...inner, addend: inner.addend + rnum * (adjusted.operator === "+" ? 1 : -1) } : null;
  }
  return null;
}

export function inferRollAdjustment(original, adjusted) {
  if (!original?.instances?.length || original.instances.length !== adjusted?.instances?.length) return null;
  let result = null;
  for (let index = 0; index < original.instances.length; index++) {
    const from = original.instances[index], to = adjusted.instances[index];
    if (from.type !== to.type || !!from.persistent !== !!to.persistent) return null;
    const a = inferTermAdjustment(from.head, to.head);
    if (!a) return null;
    if (!result) result = a;
    else if (a.multiplier !== result.multiplier || a.addend !== 0) return null;
  }
  return result;
}

/** Add an evaluated fire constant to an existing fire instance; never roll existing dice again. */
export async function addFireToRoll(original, amount, { critical = false, RollTerm } = {}) {
  if (!Number.isFinite(amount) || amount <= 0) return original;
  if (!RollTerm) throw new Error("Foundry RollTerm API is unavailable.");
  const DamageRoll = original.constructor;
  const extra = await new DamageRoll(critical ? `(2 * ${amount})[fire]` : `${amount}[fire]`, {}, clone(original.options)).evaluate();
  const instances = original.instances.map(i => i.constructor.fromData(i.toJSON()));
  const index = instances.findIndex(i => i.type === "fire" && !i.persistent);
  if (index === -1) instances.push(extra.instances[0]);
  else {
    const previous = instances[index];
    const head = RollTerm.fromData({ class: "ArithmeticExpression", operator: "+", evaluated: true, operands: [
      { class: "Grouping", evaluated: true, term: previous.head.toJSON() },
      { class: "Grouping", evaluated: true, term: extra.instances[0].head.toJSON() }
    ] });
    instances[index] = previous.constructor.fromTerms([head], clone(previous.options));
  }
  const result = DamageRoll.fromTerms([original.pool.constructor.fromRolls(instances)], clone(original.options));
  Object.assign(result.options, clone(original.options));
  return result;
}

export class KeyedQueue {
  #pending = new Map();
  async run(key, operation) {
    const prior = this.#pending.get(key) ?? Promise.resolve();
    const promise = prior.catch(() => {}).then(operation);
    this.#pending.set(key, promise);
    try { return await promise; }
    finally { if (this.#pending.get(key) === promise) this.#pending.delete(key); }
  }
}

/** Create effect data from the catalogue. Native rule elements own derived bonuses and temp HP. */
export function formData(template, actor, { manifestation = "body", worthy = false, now = 0, initiative = null } = {}) {
  if (!["body", "soul"].includes(manifestation)) throw new Error("Unknown manifestation.");
  const data = clone(template);
  delete data._id;
  data.name = `Primordial Flame — ${manifestation === "body" ? "Blazing Body" : "Blazing Soul"}${worthy ? " (Worthy of Inari)" : ""}`;
  data.system.level.value = levelOf(actor);
  data.system.start = { value: now, initiative };
  data.flags ??= {};
  data.flags[MODULE_ID] = { kind: "form", manifestation, worthy, schemaVersion: 1 };
  data.system.rules = [
    { key: "RollOption", domain: "all", option: "flameborn:primordial-flame" },
    { key: "RollOption", domain: "all", option: `flameborn:${manifestation}` },
    { key: "TempHP", value: levelOf(actor) * (worthy ? 2 : 1) },
    { key: "FlatModifier", selector: "land-speed", type: "status", label: "Primordial Flame", value: hasFeat(actor, "unbound-flame") ? 10 : 5 },
    { key: "TokenLight", value: { bright: 20, dim: 40, color: "#ff8a36", alpha: 0.22, animation: { type: "torch", speed: 2, intensity: 2 } } },
  ];
  if (manifestation === "body") data.system.rules.push(
    { key: "FlatModifier", selector: "athletics", type: "status", label: "Blazing Body", value: 1 },
    { key: "FlatModifier", selector: "strike-damage", damageType: "fire", slug: "flameborn-blazing-body", label: "Blazing Body", value: "@weapon.system.damage.dice" }
  );
  if (hasFeat(actor, "unbound-flame")) data.system.rules.push({ key: "BaseSpeed", selector: "fly", value: "@actor.system.movement.speeds.land.value" });
  if (worthy) data.system.rules.push({ key: "GrantItem", uuid: "Compendium.pf2e.conditionitems.Item.nlCjDvLMf2EkV2dl", inMemoryOnly: true });
  return data;
}
