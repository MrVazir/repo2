import { MODULE_ID as ID, VERSION, clone, levelOf, hasFeat, isFlameborn, itemSlug, itemsOf,
  moduleFlags as flags, conscious, crossedHalf, currentForm } from "./core.mjs";
import { setCatalog, queues, now, stamp, state, safe, report, authoritative, allActors,
  template, announce, cleanupActor, synchronizeSpells, chooseAlternateAthletics } from "./features.mjs";
import { preCreateMessage, createdMessage, wrapEntryCast, wrapSpellMessage, modifySpellDamage } from "./spells.mjs";
import { openControls, diagnostics, renderSheet, renderChat, interactive, feature } from "./ui.mjs";
import { registerVFXSettings, reconcileVFX, clearVFX, boundVFX } from "./vfx.mjs";

let ready = false;
let sweepRunning = false;
let sweepAgain = false;

export function reduceFireResistances(resistances, amount) {
  return resistances.map(resistance => {
    if (resistance.type !== "fire" || !(amount > 0)) return resistance;
    const reduced = new resistance.constructor(resistance.toObject());
    const originalValue = resistance.getDoubledValue.bind(resistance);
    // Native IWR checks conditional doubling before comparing applicable resistances.
    reduced.getDoubledValue = description => Math.max(0, originalValue(description) - amount);
    return reduced;
  });
}

function registerRules() {
  if (!game.pf2e?.RuleElement || !game.pf2e?.RuleElements) throw new Error("PF2e’s rule element API was not initialized.");
  class FlamebornPierceResistance extends game.pf2e.RuleElement {
    afterPrepareData() {
      if (this.ignored) return;
      const option = this.actor.getRollOptions().find(o => /^origin:flameborn:pierce:\d+$/.test(o));
      const amount = option ? Number(option.split(":").at(-1)) : 0;
      if (!(amount > 0)) return;
      const attributes = this.actor.system.attributes;
      if (attributes.resistances) attributes.resistances = reduceFireResistances(attributes.resistances, amount);
    }
  }
  game.pf2e.RuleElements.custom.FlamebornPierceResistance = FlamebornPierceResistance;
}

async function wrapDamage(wrapped, params) {
  let adjusted;
  try { adjusted = await modifySpellDamage(params, this); }
  catch (error) { report(error); return this; }
  const actual = params.token?.actor ?? fromUuidSync(this.uuid) ?? this;
  const treatment = hasFeat(actual, "burning-metabolism") && typeof adjusted.damage === "number" && adjusted.damage < 0 && !adjusted.final && adjusted.rollOptions?.has("action:treat-wounds");
  if (!treatment) return wrapped(adjusted);
  return queues.run(`${actual.uuid}:healing`, async () => {
    const cooldown = itemsOf(actual).some(i => flags(i).kind === "metabolism-cooldown" && !i.isExpired && !i.remainingDuration?.expired);
    const options = new Set(adjusted.rollOptions);
    if (cooldown) options.add("flameborn:metabolism-cooldown");
    const before = actual.system.attributes.hp.value;
    const result = await wrapped({ ...adjusted, rollOptions: options });
    if (!cooldown && actual.system.attributes.hp.value > before) {
      const data = template("metabolism-cooldown");
      data.system.start = { value: now(), initiative: actual.combatant?.initiative ?? null };
      await actual.createEmbeddedDocuments("Item", [data]);
    }
    return result;
  });
}

function registerWrappers() {
  if (!globalThis.libWrapper) throw new Error("Enable libWrapper to use Flameborn’s action and spell automation.");
  // Locate the shared PF2e base method once. This covers native contextual clones of every actor type.
  let prototype = CONFIG.PF2E.Actor.documentClasses.character.prototype;
  while (prototype && !Object.hasOwn(prototype, "applyDamage")) prototype = Object.getPrototypeOf(prototype);
  if (!prototype) throw new Error("The supported PF2e damage API was not found.");
  CONFIG.Flameborn = { damagePrototype: prototype };
  libWrapper.register(ID, "CONFIG.Flameborn.damagePrototype.applyDamage", wrapDamage, "MIXED");
  libWrapper.register(ID, "CONFIG.PF2E.Item.documentClasses.spellcastingEntry.prototype.cast", wrapEntryCast, "WRAPPER");
  libWrapper.register(ID, "CONFIG.PF2E.Item.documentClasses.spell.prototype.toMessage", wrapSpellMessage, "WRAPPER");
  libWrapper.register(ID, "game.pf2e.rollItemMacro", async function(wrapped, uuid, ...args) {
    const item = uuid.includes(".") ? await fromUuid(uuid) : canvas?.tokens?.controlled?.[0]?.actor?.items.get(uuid) ?? game.user.character?.items.get(uuid);
    const slug = flags(item).feature;
    if (item?.actor?.isOwner && interactive.has(slug)) return safe(() => feature(item.actor, slug));
    return wrapped(uuid, ...args);
  }, "MIXED");
}

async function sweep() {
  if (!ready) return;
  if (sweepRunning) { sweepAgain = true; return; }
  sweepRunning = true;
  try {
    do {
      sweepAgain = false;
      for (const actor of allActors()) if (authoritative(actor)) await cleanupActor(actor);
      await reconcileVFX();
    } while (sweepAgain);
  } finally { sweepRunning = false; }
}

Hooks.once("init", () => {
  if (game.system.id !== "pf2e") return;
  for (const key of ["ancestryTraits", "featTraits", "actionTraits", "creatureTraits", "heritageTraits"]) {
    if (CONFIG.PF2E[key]) CONFIG.PF2E[key].flameborn = "Flameborn";
  }
  CONFIG.PF2E.traitsDescriptions.flameborn = "A human blessed by Inari’s divine fire before birth.";
  registerVFXSettings();
  registerRules();
  game.modules.get(ID).api = {
    version: VERSION, openControls: actor => safe(() => openControls(actor)), diagnostics: () => safe(diagnostics),
    use: (actor, slug) => safe(() => feature(actor, slug)), refresh: () => safe(sweep),
  };
});

Hooks.once("setup", () => { if (game.system.id === "pf2e") { try { registerWrappers(); } catch (error) { report(error); } } });
Hooks.once("ready", () => { void safe(async () => {
  if (game.system.id !== "pf2e") return;
  const response = await fetch(`modules/${ID}/data/catalog.json`);
  if (!response.ok) throw new Error("The Flameborn content catalog could not be loaded. Check that the complete module folder was installed.");
  setCatalog(await response.json());
  ready = true;
  for (const actor of allActors()) if (authoritative(actor) && isFlameborn(actor)) await synchronizeSpells(actor);
  await sweep();
  if (game.user.isGM && (!String(game.version).startsWith("14.") || game.system.version !== "8.5.0")) ui.notifications.info("Flameborn 1.0.0 was built against Foundry 14.364 and PF2e 8.5.0. Run Flameborn Diagnostics after a system update.");
  console.info(`${ID} ${VERSION} | Ready`);
}); });

Hooks.on("renderActorSheet", renderSheet);
Hooks.on("renderActorSheetV2", renderSheet);
Hooks.on("renderChatMessageHTML", renderChat);
Hooks.on("preCreateChatMessage", preCreateMessage);
Hooks.on("createChatMessage", createdMessage);
Hooks.on("preCreateItem", (item, data, options, userId) => {
  if (item.actor && itemSlug(item) === "peak-physiology" && hasFeat(item.actor, "titan-wrestler")) item.updateSource({ [`flags.${ID}.needsAthleticsFeat`]: true });
});
Hooks.on("createItem", (item, options, userId) => {
  if (!ready || !item.actor) return;
  if (["heritage", "feat"].includes(item.type) && userId === game.user.id && item.actor.isOwner) void safe(async () => {
    await synchronizeSpells(item.actor);
    await cleanupActor(item.actor);
    if (flags(item).needsAthleticsFeat) await chooseAlternateAthletics(item.actor);
  });
  if (flags(item).kind === "form") void safe(reconcileVFX);
});
Hooks.on("updateItem", (item, changes, options, userId) => {
  if (!ready || !item.actor) return;
  if (itemSlug(item) === "kindled-soul" && userId === game.user.id) void safe(() => synchronizeSpells(item.actor));
  if (flags(item).kind) void safe(sweep);
});
Hooks.on("deleteItem", (item, options, userId) => {
  if (!ready || !item.actor) return;
  if (["heritage", "feat"].includes(item.type) && userId === game.user.id && item.actor.isOwner) void safe(async () => {
    await synchronizeSpells(item.actor);
    await cleanupActor(item.actor);
    if (itemSlug(item) === "peak-physiology") {
      const grants = itemsOf(item.actor).filter(i => flags(i).grantedByPeak === item.id);
      if (grants.length) await item.actor.deleteEmbeddedDocuments("Item", grants.map(i => i.id));
    }
  });
  if (flags(item).kind === "form") void safe(async () => {
    if (authoritative(item.actor)) {
      const dependants = itemsOf(item.actor).filter(i => flags(i).parentForm === item.id);
      if (dependants.length) await item.actor.deleteEmbeddedDocuments("Item", dependants.map(i => i.id));
      await state(item.actor, { pendingSpell: null });
    }
    await reconcileVFX();
  });
});

Hooks.on("preUpdateActor", (actor, changes, options) => {
  if (!ready || !hasFeat(actor, "flame-fed-by-trial") || options.damageUndo) return;
  const hp = foundry.utils.getProperty(changes, "system.attributes.hp.value") ?? changes["system.attributes.hp.value"];
  if (hp !== undefined) options.flamebornPreviousHP = { value: actor.system.attributes.hp.value, max: actor.system.attributes.hp.max };
});
Hooks.on("updateActor", (actor, changes, options, userId) => {
  if (!ready) return;
  if (options.flamebornPreviousHP && userId === game.user.id && actor.isOwner && !options.damageUndo) void safe(async () => {
    const before = options.flamebornPreviousHP;
    if (conscious(actor) && crossedHalf(before.value, actor.system.attributes.hp.value, before.max)) {
      await state(actor, { trialWindow: { stamp: stamp(), time: now() } });
      await announce(actor, "Flame Fed by Trial — possible trigger", "<p>Your HP crossed from above half to half or fewer. If a hostile creature’s damage caused this and your reaction is available, you can use Flame Fed by Trial.</p>", { trial: true }, { whisper: true });
    }
  });
  void safe(reconcileVFX);
});

for (const hook of ["updateWorldTime", "updateCombat", "deleteCombat", "canvasReady"]) Hooks.on(hook, () => { void safe(sweep); });
Hooks.on("canvasTearDown", () => { void safe(clearVFX); });
Hooks.on("createToken", () => { void safe(reconcileVFX); });
Hooks.on("deleteToken", () => { void safe(reconcileVFX); });
Hooks.on("flameborn.bound", actor => { void safe(() => boundVFX(actor)); });
Hooks.on("pf2e.restForTheNight", actor => { if (ready && actor.isOwner) void safe(async () => {
  await state(actor, { pendingSpell: null, lastCast: null, soulTurn: null, trialWindow: null });
  const effects = itemsOf(actor).filter(i => ["form", "temporary-hp", "metabolism-cooldown"].includes(flags(i).kind));
  if (effects.length) await actor.deleteEmbeddedDocuments("Item", effects.map(i => i.id));
  const feats = itemsOf(actor).filter(i => i.type === "feat" && flags(i).readyAt != null);
  if (feats.length) await actor.updateEmbeddedDocuments("Item", feats.map(i => ({ _id: i.id, [`flags.${ID}.readyAt`]: null })));
}); });
