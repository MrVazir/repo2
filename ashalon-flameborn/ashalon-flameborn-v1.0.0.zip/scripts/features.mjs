import { MODULE_ID as ID, clone, escapeHTML as esc, levelOf, itemsOf, itemSlug, findFeat, hasFeat,
  isFlameborn, moduleFlags as flags, stateOf, currentForm, conscious, remainingUses, turnStamp,
  ownTurn, formData, KeyedQueue, canRerollAthletics } from "./core.mjs";

export const queues = new KeyedQueue();
let catalog;
export const setCatalog = value => { catalog = value; };
export const getCatalog = () => catalog;
export const now = () => game.time.worldTime;
export const stamp = () => turnStamp(game.combat);
export const safe = operation => Promise.resolve().then(operation).catch(report);
export function report(error) { console.error(`${ID} |`, error); ui.notifications.error(`Flameborn: ${error.message ?? error}`); }
export function requireOwner(actor) {
  if (!actor?.isOwner) throw new Error("Select a character you own, or ask its owner or the GM to use this control.");
}
export function requireFlameborn(actor) {
  requireOwner(actor);
  if (!isFlameborn(actor)) throw new Error("Add the Flameborn heritage to this character first.");
}
export function requireFeat(actor, slug) {
  requireFlameborn(actor);
  const feat = findFeat(actor, slug);
  if (!feat) throw new Error(`This character does not have ${slug.replaceAll("-", " ")}.`);
  if (levelOf(actor) < feat.system.level.value) throw new Error(`This feat requires level ${feat.system.level.value}.`);
  return feat;
}
export function authoritative(actor) {
  const leader = game.users.activeGM ?? game.users.find(u => u.active && actor.testUserPermission(u, "OWNER"));
  return leader?.id === game.user.id;
}
export function allActors() {
  const result = new Map(game.actors.map(a => [a.uuid, a]));
  for (const scene of game.scenes) for (const token of scene.tokens) if (token.actor) result.set(token.actor.uuid, token.actor);
  return [...result.values()];
}
export async function state(actor, changes) {
  return actor.update(Object.fromEntries(Object.entries(changes).map(([k, v]) => [`flags.${ID}.state.${k}`, v])));
}
export function template(kind) {
  const data = clone(catalog.effects.find(e => flags(e).kind === kind));
  if (!data) throw new Error(`Effect template is missing: ${kind}`);
  delete data._id;
  return data;
}
export async function spend(feat) {
  const uses = remainingUses(feat, now());
  if (uses < 1) throw new Error(`${feat.name} has no uses remaining.`);
  const previous = { value: feat.system.frequency?.value ?? feat.system.frequency?.max, readyAt: flags(feat).readyAt ?? null };
  if (Number.isFinite(uses)) await feat.update({ "system.frequency.value": uses - 1,
    [`flags.${ID}.readyAt`]: feat.system.frequency.per === "PT10M" ? now() + 600 : null });
  return async () => { if (Number.isFinite(uses)) await feat.update({ "system.frequency.value": previous.value, [`flags.${ID}.readyAt`]: previous.readyAt }); };
}
export async function announce(actor, title, body, extraFlags = {}, { whisper = false } = {}) {
  const recipients = whisper ? game.users.filter(u => u.isGM || actor.testUserPermission(u, "OWNER")).map(u => u.id) : [];
  return ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }),
    content: `<div class="flameborn-card"><strong>${esc(title)}</strong>${body}</div>`,
    flags: { [ID]: { actorUuid: actor.uuid, ...extraFlags } }, ...(whisper ? { whisper: recipients } : {}) });
}

export async function activate(actor, { trial = false } = {}) {
  requireFeat(actor, trial ? "flame-fed-by-trial" : "primordial-flame");
  requireFeat(actor, "primordial-flame");
  if (!conscious(actor)) throw new Error("Primordial Flame requires a conscious character.");
  const existing = currentForm(actor);
  if (existing && !trial) throw new Error("Primordial Flame is already active. Dismiss it before activating it again.");
  if (trial) {
    const confirmed = await foundry.applications.api.DialogV2.confirm({ window: { title: "Flame Fed by Trial" }, rejectClose: false,
      content: "<p>Use your reaction after a hostile creature’s damage takes you from above half your maximum HP to half or fewer, while you remain conscious.</p><p>Did this trigger just occur, and is your reaction available?</p>" });
    if (!confirmed) return;
  }
  const empowered = findFeat(actor, "worthy-of-inari");
  const choice = existing ? {} : await foundry.applications.api.DialogV2.input({ window: { title: "Awaken Primordial Flame" },
    content: `<div class="flameborn-form"><label>Manifestation<select name="manifestation"><option value="body">Blazing Body — Strikes and Athletics</option><option value="soul">Blazing Soul — spell benefits</option></select></label>
    ${empowered && remainingUses(empowered, now()) > 0 ? '<label class="checkbox"><input type="checkbox" name="worthy">Worthy of Inari — double activation temp HP; quickened for Stride or Strike (once per day)</label>' : ""}
    <p>The transformation lasts 1 minute. ${trial ? "This uses your reaction and Flame Fed by Trial’s daily use." : "This costs 1 action and a normal daily activation."}</p></div>`, ok: { label: "Transform" } });
  if (!choice) return;
  return queues.run(actor.uuid, async () => {
    requireFeat(actor, "primordial-flame");
    await cleanupActor(actor);
    if (!conscious(actor)) throw new Error("The character is no longer conscious.");
    const form = currentForm(actor);
    if (form && !trial) throw new Error("Primordial Flame is already active.");
    const undo = [], created = [];
    try {
      undo.push(await spend(requireFeat(actor, trial ? "flame-fed-by-trial" : "primordial-flame")));
      if (form) {
        const data = template("temporary-hp");
        data.name = "Flame Fed by Trial — renewed resolve";
        data.system.level.value = levelOf(actor);
        data.system.duration = clone(form.system.duration);
        data.system.start = clone(form.system.start);
        data.flags[ID].parentForm = form.id;
        created.push(...await actor.createEmbeddedDocuments("Item", [data]));
        // PF2e assigns a new start time in Effect._preCreate. Restore the parent's
        // start after creation so this refresh cannot extend the transformation.
        for (const effect of created) await effect.update({ "system.start": clone(form.system.start) });
      } else {
        if (choice.worthy) undo.push(await spend(requireFeat(actor, "worthy-of-inari")));
        const data = formData(template("form"), actor, { manifestation: choice.manifestation ?? "body", worthy: !!choice.worthy,
          now: now(), initiative: actor.combatant?.initiative ?? null });
        data.system.description.value = findFeat(actor, "primordial-flame").system.description.value;
        created.push(...await actor.createEmbeddedDocuments("Item", [data]));
      }
      if (!created.length) throw new Error("The effect could not be created.");
    } catch (error) {
      if (created.length) await actor.deleteEmbeddedDocuments("Item", created.map(e => e.id));
      for (const rollback of undo.reverse()) await rollback();
      throw error;
    }
    await state(actor, { trialWindow: null });
    await announce(actor, trial ? "Flame Fed by Trial — reaction" : "Primordial Flame — 1 action",
      `<p>${form ? "Temporary HP refreshed; the current transformation’s duration is unchanged." : esc(created[0].name) + " awakens for 1 minute."}</p>${choice.worthy ? "<p>The quickened action can be used only to Stride or Strike.</p>" : ""}`);
    return created[0];
  });
}

export async function dismiss(actor) {
  requireOwner(actor);
  return queues.run(actor.uuid, async () => {
    const form = currentForm(actor);
    if (!form) return;
    await actor.deleteEmbeddedDocuments("Item", [form.id, ...itemsOf(actor).filter(i => flags(i).parentForm === form.id).map(i => i.id)]);
    await state(actor, { pendingSpell: null });
    await announce(actor, "Dismiss Primordial Flame — 1 action", "<p>The transformation ends.</p>");
  });
}

export async function reroll(message) {
  const actor = message?.actor;
  requireFeat(actor, "surpass-your-limits");
  if (!message.isAuthor && !game.user.isGM) throw new Error("The original roller or a GM must reroll this check.");
  return queues.run(actor.uuid, async () => {
    if (!canRerollAthletics(message)) throw new Error("Choose a failed Athletics check that has not already been rerolled or affected by fortune or misfortune.");
    const undo = await spend(findFeat(actor, "surpass-your-limits"));
    try { await game.pf2e.Check.rerollFromMessage(message, { keep: "best" }); }
    catch (error) { await undo(); throw error; }
  });
}

export async function bound(actor) {
  requireFeat(actor, "explosive-bound");
  if ((actor.skills?.athletics?.rank ?? actor.system.skills?.athletics?.rank ?? 0) < 2) throw new Error("Explosive Bound requires expert Athletics.");
  const choice = await foundry.applications.api.DialogV2.confirm({ window: { title: "Explosive Bound" }, rejectClose: false,
    content: `<p>From a solid surface, Leap up to ${2 * (actor.system.movement.speeds.land.value ?? 0)} feet horizontally, or up to 20 feet vertically and 5 feet horizontally. Move your token along the legal path.</p><p>Spend 1 action and use Explosive Bound?</p>` });
  if (!choice) return;
  await queues.run(actor.uuid, () => spend(findFeat(actor, "explosive-bound")));
  await announce(actor, "Explosive Bound — 1 action", `<p>Leap up to ${2 * actor.system.movement.speeds.land.value} feet horizontally, or 20 feet vertically and 5 feet horizontally. No Athletics check is required. Falls and landing surfaces apply normally.</p>`);
  Hooks.callAll("flameborn.bound", actor);
}

export async function synchronizeSpells(actor) {
  if (!actor?.isOwner || actor.type !== "character") return;
  return queues.run(`${actor.uuid}:spells`, async () => {
    const kindled = findFeat(actor, "kindled-soul");
    const ability = kindled?.flags?.pf2e?.rulesSelections?.ability;
    const wanted = isFlameborn(actor) && kindled ? ["ignition", ...(hasFeat(actor, "inaris-spellcraft") ? ["fireball", "fire-shield"] : [])] : [];
    const obsolete = itemsOf(actor).filter(i => flags(i).managedSpell && !wanted.includes(flags(i).managedSpell));
    if (obsolete.length) await actor.deleteEmbeddedDocuments("Item", obsolete.map(i => i.id));
    let entry = itemsOf(actor).find(i => i.type === "spellcastingEntry" && flags(i).innateEntry);
    if (!wanted.length) {
      if (entry && !itemsOf(actor).some(i => i.type === "spell" && i.system.location.value === entry.id)) await entry.delete();
      return;
    }
    if (!["int", "wis", "cha"].includes(ability)) return;
    if (!entry) [entry] = await actor.createEmbeddedDocuments("Item", [{ name: "Flameborn — Divine Innate Spells", type: "spellcastingEntry",
      img: `modules/${ID}/icons/soul.svg`, flags: { [ID]: { innateEntry: true } }, system: {
        ability: { value: ability }, tradition: { value: "divine" }, prepared: { value: "innate", flexible: false },
        proficiency: { slug: "", value: 1 }, spelldc: { value: 0, dc: 0 }, autoHeightenLevel: { value: null },
        showSlotlessLevels: { value: true }, traits: { otherTags: [] },
        slots: Object.fromEntries(Array.from({ length: 11 }, (_, n) => [`slot${n}`, { prepared: [], value: 0, max: 0 }]))
      } }]);
    else if (entry.system.ability.value !== ability) await entry.update({ "system.ability.value": ability });
    if (!entry) throw new Error("Could not create the Flameborn innate spellcasting entry.");
    for (const slug of wanted) {
      const existing = itemsOf(actor).find(i => flags(i).managedSpell === slug);
      if (existing) continue;
      const original = await fromUuid(catalog.references[slug]);
      if (!original) throw new Error(`Could not load ${slug} from the PF2e spell compendium.`);
      const data = original.toObject(); delete data._id;
      data.flags ??= {}; data.flags[ID] = { managedSpell: slug };
      data.system.location = { value: entry.id, heightenedLevel: slug === "fireball" ? 3 : slug === "fire-shield" ? 4 : null,
        uses: { value: 1, max: 1 }, atWill: slug === "ignition" };
      await actor.createEmbeddedDocuments("Item", [data]);
    }
  });
}

export async function chooseAlternateAthletics(actor) {
  requireFeat(actor, "peak-physiology");
  const peak = findFeat(actor, "peak-physiology");
  if (!flags(peak).needsAthleticsFeat || flags(peak).alternateFeatUuid) return;
  const rank = actor.skills?.athletics?.rank ?? actor.system.skills.athletics.rank;
  const choices = catalog.athleticsSkillFeats.filter(c => c.level <= levelOf(actor) && c.rank <= rank && !itemsOf(actor).some(i => i.name === c.name));
  if (!choices.length) { ui.notifications.info("Peak Physiology: choose an eligible Athletics skill feat with your GM."); return; }
  const choice = await foundry.applications.api.DialogV2.input({ window: { title: "Peak Physiology — bonus skill feat" },
    content: `<p>You already have Titan Wrestler. Choose another eligible Athletics skill feat. For a feat with additional prerequisites, ask the GM to add it instead.</p><select name="uuid">${choices.map(c => `<option value="${esc(c.uuid)}">${esc(c.name)}</option>`).join("")}</select>`, ok: { label: "Add Feat" } });
  if (!choice) return;
  await queues.run(actor.uuid, async () => {
    if (flags(peak).alternateFeatUuid) return;
    if (!choices.some(c => c.uuid === choice.uuid)) throw new Error("Invalid skill feat.");
    const data = (await fromUuid(choice.uuid)).toObject(); delete data._id;
    data.system.location = peak.id;
    data.flags ??= {}; data.flags[ID] = { grantedByPeak: peak.id };
    const [feat] = await actor.createEmbeddedDocuments("Item", [data]);
    if (feat) await peak.update({ [`flags.${ID}.alternateFeatUuid`]: feat.uuid, [`flags.${ID}.needsAthleticsFeat`]: false });
  });
}

export async function cleanupActor(actor) {
  if (!actor?.isOwner) return;
  const combat = game.combat;
  const expired = itemsOf(actor).filter(item => {
    const f = flags(item);
    if (item.type !== "effect" || !f.kind) return false;
    if (f.parentForm && !actor.items.get(f.parentForm)) return true;
    if (f.kind === "form" && (!isFlameborn(actor) || !hasFeat(actor, "primordial-flame"))) return true;
    if (f.casterTurn && combat?.id === f.casterTurn.combatId && combat.started) {
      const later = combat.round > f.casterTurn.round || (combat.round === f.casterTurn.round && combat.turn > f.casterTurn.turn);
      if (later && combat.combatant?.actor?.uuid === f.casterTurn.actorUuid) return true;
    }
    return !!item.isExpired || !!item.system.expired || !!item.remainingDuration?.expired;
  });
  if (expired.length) await actor.deleteEmbeddedDocuments("Item", expired.map(i => i.id));
  const updates = itemsOf(actor).filter(i => i.type === "feat" && Number.isFinite(flags(i).readyAt) && now() >= flags(i).readyAt)
    .map(i => ({ _id: i.id, "system.frequency.value": i.system.frequency?.max ?? 1, [`flags.${ID}.readyAt`]: null }));
  if (updates.length) await actor.updateEmbeddedDocuments("Item", updates);
  const pending = stateOf(actor).pendingSpell;
  if (pending && ((combat?.started && pending.stamp !== stamp()) || now() - pending.time > 60)) await state(actor, { pendingSpell: null });
}

export async function makeShield(actor, amount, { title, seconds = 60, caster, sourceId, short = false } = {}) {
  requireOwner(actor);
  const data = template("temporary-hp");
  data.name = title; data.system.level.value = amount;
  data.system.start = { value: now(), initiative: caster?.combatant?.initiative ?? null };
  data.system.duration = { value: seconds / 6, unit: "rounds", expiry: "turn-start", sustained: false };
  data.flags[ID].shieldSource = sourceId;
  if (caster) data.system.context = {
    origin: { actor: caster.uuid, token: caster.getActiveTokens()?.[0]?.document.uuid ?? null, item: null, spellcasting: null, rollOptions: [] },
    target: { actor: actor.uuid, token: actor.getActiveTokens()?.[0]?.document.uuid ?? null }, roll: null,
  };
  if (short && game.combat?.started && caster) data.flags[ID].casterTurn = {
    combatId: game.combat.id, round: game.combat.round, turn: game.combat.turn, actorUuid: caster.uuid };
  const [created] = await actor.createEmbeddedDocuments("Item", [data]);
  return created;
}
