import { MODULE_ID as ID, clone, escapeHTML as esc, levelOf, findFeat, hasFeat, isFlameborn,
  moduleFlags as flags, stateOf, currentForm, ownTurn, eligibleConduit, castActions,
  inferRollAdjustment, addFireToRoll } from "./core.mjs";
import { queues, now, stamp, state, spend, requireFeat, requireOwner, announce, makeShield, safe } from "./features.mjs";

const inFlight = new Map();
const entryFlight = new Map();
const damageClaimed = new Set();
const seenShields = new Set();
const randomID = () => foundry.utils.randomID();
export function targetsFor(actor) {
  const targets = [...game.user.targets].filter(t => t.actor).map(t => ({ actorUuid: t.actor.uuid, tokenUuid: t.document.uuid, name: t.name }));
  return [{ actorUuid: actor.uuid, tokenUuid: actor.getActiveTokens()?.[0]?.document.uuid ?? null, name: `${actor.name} (self)` }, ...targets.filter(t => t.actorUuid !== actor.uuid)];
}
function targetSelect(actor, field = "target") {
  return `<label>Chosen creature<select name="${field}">${targetsFor(actor).map(t => `<option value="${esc(t.tokenUuid ?? t.actorUuid)}">${esc(t.name)}</option>`).join("")}</select></label>`;
}
function actionCount(spell, pending) {
  const fixed = castActions(spell);
  if (fixed !== null) return fixed;
  const text = String(spell.system.time?.value ?? "");
  if (!/^\s*[123](?:\s*(?:to|or|-)\s*[123])+\s*$/.test(text)) return null;
  const numbers = text.match(/[123]/g).map(Number);
  const n = Number(pending.actions);
  return n >= Math.min(...numbers) && n <= Math.max(...numbers) ? n : null;
}
function actionsSelect() {
  return '<label>For a spell with a variable action cost<select name="actions"><option value="">Use its listed casting time</option><option value="1">1 action</option><option value="2">2 actions</option><option value="3">3 actions</option></select></label>';
}

export async function armSpell(actor, feature = "soul") {
  requireOwner(actor);
  if (feature === "soul") {
    requireFeat(actor, "primordial-flame");
    if (flags(currentForm(actor)).manifestation !== "soul") throw new Error("Blazing Soul must be active.");
    if (!ownTurn(actor, game.combat) || stateOf(actor).soulTurn === stamp()) throw new Error("Blazing Soul is available once on each of your own turns.");
  } else requireFeat(actor, feature);
  if (feature === "living-conduit" && !currentForm(actor)) throw new Error("Primordial Flame must be active.");
  const content = feature === "soul" ? `<p>Choose before resolving your next spell. Its normal casting time must be 2 or 3 actions.</p><label>Benefit<select name="benefit"><option value="searing">Searing magic — extra fire damage to this creature</option><option value="sheltering">Sheltering magic — temporary HP after resolution</option></select></label>${targetSelect(actor)}${actionsSelect()}` :
    feature === "emberward-spell" ? `<p>Spend 1 action. Your next action must Cast a Spell that targets a willing creature. Target that creature before opening this control.</p>${targetSelect(actor)}<p>This uses Emberward Spell for the next 10 minutes, even if you interrupt the sequence.</p>` :
    feature === "piercing-embers" ? '<p>Spend 1 action. Your next action must Cast a Spell that deals fire damage. Its initial fire damage ignores fire resistance equal to half your level (rounded down).</p><p>This replaces another pending spellshape action.</p>' :
    `<p>Your next eligible casting uses Living Conduit without expending its available class or archetype spell slot. The spell must be at least 2 ranks below your highest spell slot, take 1–3 actions, and have no monetary or material cost.</p>${actionsSelect()}`;
  const choice = await foundry.applications.api.DialogV2.input({ window: { title: feature === "soul" ? "Blazing Soul — next spell" : findFeat(actor, feature).name }, content: `<div class="flameborn-form">${content}</div>`, ok: { label: feature === "soul" || feature === "living-conduit" ? "Ready Benefit" : "Use Spellshape" } });
  if (!choice) return;
  return queues.run(actor.uuid, async () => {
    const prior = stateOf(actor).pendingSpell;
    const pending = prior?.stamp === stamp() && now() - prior.time <= 60 ? clone(prior) : {};
    Object.assign(pending, { stamp: stamp(), time: now(), actions: choice.actions || pending.actions || null });
    const selected = choice.target ? targetsFor(actor).find(t => (t.tokenUuid ?? t.actorUuid) === choice.target) : null;
    if (choice.target && !selected) throw new Error("The chosen target is no longer available. Target it and try again.");
    let rollback;
    if (feature === "soul") {
      if (flags(currentForm(actor)).manifestation !== "soul" || stateOf(actor).soulTurn === stamp()) throw new Error("Blazing Soul is no longer available.");
      pending.soul = { mode: choice.benefit, target: selected };
    } else if (feature === "living-conduit") pending.conduit = true;
    else {
      if (feature === "emberward-spell") rollback = await spend(findFeat(actor, feature));
      pending.shape = feature === "emberward-spell" ? { kind: "emberward", target: selected } : { kind: "piercing" };
    }
    try { await state(actor, { pendingSpell: pending }); }
    catch (error) { if (rollback) await rollback(); throw error; }
    ui.notifications.info("Flameborn benefit ready. Cast your spell normally from the sheet. Clear the benefit if you take another action first.");
  });
}

/** Wrap the real slot-casting method. Never restore an expended spell or grant a new slot. */
export async function wrapEntryCast(wrapped, spell, options = {}) {
  const actor = this.actor;
  if (!actor || !isFlameborn(actor) || !stateOf(actor).pendingSpell?.conduit || options.consume === false || options.message === false) return wrapped(spell, options);
  return queues.run(`${actor.uuid}:cast`, async () => {
    const pending = stateOf(actor).pendingSpell;
    const rank = Number(options.rank ?? spell.rank);
    if (pending?.stamp !== stamp() || !eligibleConduit(actor, this, spell, rank, options.slotId, actionCount(spell, pending))) {
      throw new Error("Living Conduit is not eligible for this casting. Clear the pending benefit to spend the spell slot normally.");
    }
    const rollback = await spend(requireFeat(actor, "living-conduit"));
    const flight = { conduit: true, created: false };
    entryFlight.set(actor.uuid, flight);
    try {
      const result = await wrapped(spell, { ...options, consume: false });
      if (!flight.created) await rollback();
      return result;
    } catch (error) { await rollback(); throw error; }
    finally { entryFlight.delete(actor.uuid); }
  });
}

/** Captures an actual casting, including innate spells and spells from items. Display-only cards do nothing. */
export async function wrapSpellMessage(wrapped, event, options = {}) {
  const actor = this.actor;
  const pending = actor && stateOf(actor).pendingSpell;
  if (!actor || !isFlameborn(actor) || !options.actualCast || options.create === false || !pending || inFlight.has(actor.uuid)) return wrapped(event, options);
  if (pending.stamp !== stamp() || now() - pending.time > 60) {
    await state(actor, { pendingSpell: null });
    return wrapped(event, options);
  }
  const actions = actionCount(this, pending);
  const form = currentForm(actor);
  const soul = pending.soul && flags(form).manifestation === "soul" && [2, 3].includes(actions) && ownTurn(actor, game.combat) && stateOf(actor).soulTurn !== stamp() ? pending.soul : null;
  if (pending.soul && !soul) ui.notifications.warn("Blazing Soul did not apply: it requires your own turn, an unused benefit, and a normal 2- or 3-action casting.");
  const meta = {
    nonce: randomID(), actorUuid: actor.uuid, spellUuid: (this.original ?? this).uuid,
    spellName: this.name, rank: Number(options.data?.castRank ?? this.rank), level: levelOf(actor),
    soul: clone(soul), shape: clone(pending.shape ?? null), conduit: !!entryFlight.get(actor.uuid)?.conduit,
    stamp: stamp(), time: now(), messageId: null, damageMessageId: null,
  };
  inFlight.set(actor.uuid, meta);
  try {
    const result = await wrapped(event, options);
    if (meta.messageId) {
      const flight = entryFlight.get(actor.uuid); if (flight) flight.created = true;
      await state(actor, { pendingSpell: null, lastCast: clone(meta), ...(soul ? { soulTurn: stamp() } : {}) });
    }
    return result;
  } finally { inFlight.delete(actor.uuid); }
}

export function preCreateMessage(message) {
  const actor = message.actor;
  if (!actor) return;
  const pf = message.flags.pf2e ?? {};
  const actual = pf.origin?.rollOptions?.includes("origin:action:slug:cast-a-spell");
  const flight = inFlight.get(actor.uuid);
  if (actual && flight) {
    const meta = clone(flight);
    message.updateSource({ [`flags.${ID}.cast`]: meta });
    return;
  }
  if (pf.context?.type !== "damage-roll") return;
  const meta = stateOf(actor).lastCast;
  if (!meta || meta.damageMessageId || damageClaimed.has(meta.nonce) || meta.stamp !== stamp() || now() - meta.time > 60) return;
  if (pf.origin?.uuid !== meta.spellUuid || Number(pf.origin?.castRank ?? meta.rank) !== meta.rank) return;
  const roll = message.rolls?.[0];
  if (!roll?.instances?.some(i => !i.persistent && i.kinds?.has("damage"))) return;
  const searing = meta.soul?.mode === "searing";
  const piercing = meta.shape?.kind === "piercing" && (searing || roll.instances.some(i => i.type === "fire" && !i.persistent));
  if (!searing && !piercing) return;
  const damage = { ...clone(meta), nonce: randomID(), castNonce: meta.nonce, searing, piercing };
  const options = [...(pf.context.options ?? []), `flameborn:damage:${damage.nonce}`];
  if (piercing) options.push("flameborn:piercing-embers", `self:flameborn:pierce:${Math.floor(meta.level / 2)}`);
  message.updateSource({ [`flags.${ID}.damage`]: damage, "flags.pf2e.context.options": options });
  damageClaimed.add(meta.nonce);
  // Bound memory without allowing a recent roll to be tagged twice.
  if (damageClaimed.size > 500) damageClaimed.delete(damageClaimed.values().next().value);
}

export function createdMessage(message, options, userId) {
  if (userId !== game.user.id) return;
  const meta = flags(message).cast;
  if (meta) {
    const flight = inFlight.get(meta.actorUuid);
    if (flight?.nonce === meta.nonce) flight.messageId = message.id;
  }
  const damage = flags(message).damage;
  if (damage && message.actor?.isOwner) safe(async () => {
    const latest = stateOf(message.actor).lastCast;
    if (latest?.nonce === damage.castNonce) await state(message.actor, { lastCast: { ...clone(latest), damageMessageId: message.id } });
  });
  // Observed non-spell actions break a pending spellshape sequence. Foundry does not log every movement action.
  if (!meta && !damage && message.actor?.isOwner && stateOf(message.actor).pendingSpell && !flags(message).actorUuid) {
    const context = message.flags.pf2e?.context;
    const actionCard = message.item?.type === "action" || message.item?.type === "feat";
    if (actionCard || ["attack-roll", "skill-check"].includes(context?.type)) safe(() => state(message.actor, { pendingSpell: null }));
  }
}

export async function modifySpellDamage(params, target) {
  if (typeof params.damage === "number" || params.final) return params;
  const marker = [...(params.rollOptions ?? [])].find(o => o.startsWith("flameborn:damage:"));
  if (!marker) return params;
  const nonce = marker.slice("flameborn:damage:".length);
  const message = game.messages.find(m => flags(m).damage?.nonce === nonce);
  const meta = flags(message).damage;
  if (!meta?.searing) return params;
  const chosen = meta.soul.target;
  if (chosen.tokenUuid ? params.token?.uuid !== chosen.tokenUuid : target.uuid !== chosen.actorUuid) return params;
  const original = message.rolls[0];
  const adjustment = inferRollAdjustment(original, params.damage);
  if (!adjustment) throw new Error("Another module rewrote this damage roll in an unsupported way. Flameborn stopped the application so the GM can resolve this roll manually.");
  const augmented = await addFireToRoll(original, meta.rank, {
    critical: message.flags.pf2e.context.outcome === "criticalSuccess",
    RollTerm: foundry.dice.terms.RollTerm,
  });
  const damage = augmented.alter(adjustment.multiplier, adjustment.addend);
  Object.assign(damage.options, clone(original.options));
  return { ...params, damage, breakdown: [...(params.breakdown ?? []), `Blazing Soul: +${meta.rank} fire before degree-of-success adjustments`] };
}

export async function applySpellShield(message, benefit) {
  const meta = flags(message).cast;
  if (!meta || !["sheltering", "emberward"].includes(benefit)) throw new Error("This chat card has no valid Flameborn shield.");
  const target = benefit === "sheltering" && meta.soul?.mode === "sheltering" ? meta.soul.target : benefit === "emberward" && meta.shape?.kind === "emberward" ? meta.shape.target : null;
  if (!target) throw new Error("No creature was chosen for this benefit.");
  const actor = await fromUuid(target.actorUuid);
  requireOwner(actor);
  const caster = await fromUuid(meta.actorUuid);
  const sourceId = `${message.id}:${benefit}`;
  if (seenShields.has(sourceId) || flags(message).resolved?.[benefit] || actor.items.some(i => flags(i).shieldSource === sourceId)) throw new Error("This shield has already been applied.");
  if (benefit === "sheltering" && meta.stamp !== stamp()) throw new Error("Sheltering magic’s resolution window has ended.");
  if (now() - meta.time > 60) throw new Error("This spell’s resolution window has ended.");
  const proceed = await foundry.applications.api.DialogV2.confirm({ window: { title: "Resolve Flameborn protection" }, rejectClose: false,
    content: `<p>Has ${esc(meta.spellName)} resolved? ${benefit === "sheltering" ? "The recipient must be the caster or a willing creature affected by the spell." : "The recipient must be a willing creature targeted by the spell."}</p><p>Apply ${benefit === "sheltering" ? meta.rank : meta.level} temporary HP to ${esc(actor.name)}?</p>` });
  if (!proceed) return;
  return queues.run(actor.uuid, async () => {
    if (seenShields.has(sourceId) || flags(message).resolved?.[benefit] || actor.items.some(i => flags(i).shieldSource === sourceId)) return;
    const effect = await makeShield(actor, benefit === "sheltering" ? meta.rank : meta.level, {
      title: benefit === "sheltering" ? "Blazing Soul — Sheltering Magic" : "Emberward Spell",
      seconds: benefit === "sheltering" ? 6 : 60, caster, sourceId, short: benefit === "sheltering" });
    if (!effect) throw new Error("The shield effect was not created.");
    seenShields.add(sourceId);
    if (message.isAuthor || game.user.isGM) await message.update({ [`flags.${ID}.resolved.${benefit}`]: true });
    await announce(actor, effect.name, `<p>Gains ${benefit === "sheltering" ? meta.rank : meta.level} temporary HP, subject to the normal rule for keeping the larger temporary HP pool.</p>`);
  });
}
